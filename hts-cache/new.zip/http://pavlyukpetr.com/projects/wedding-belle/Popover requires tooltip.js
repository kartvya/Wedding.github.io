<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Page not found &#8211; Fairytheme</title>
<meta name='robots' content='noindex,nofollow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Fairytheme &raquo; Feed" href="https://pavlyukpetr.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Fairytheme &raquo; Comments Feed" href="https://pavlyukpetr.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/pavlyukpetr.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.2"}};
			/*! This file is auto-generated */
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://pavlyukpetr.com/wp-includes/css/dist/block-library/style.min.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='http://pavlyukpetr.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=2.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='http://pavlyukpetr.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://pavlyukpetr.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://pavlyukpetr.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.1.0' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=4.3.0' type='text/css' media='all' />
<style id='woocommerce-layout-inline-css' type='text/css'>

	.infinite-scroll .woocommerce-pagination {
		display: none;
	}
</style>
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=4.3.0' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=4.3.0' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='neuron-style-css'  href='http://pavlyukpetr.com/wp-content/plugins/neuron-core-kyoto//assets/styles/style.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='kyoto-main-style-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/styles/kyoto.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/styles/magnific-popup.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/styles/owl.carousel.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='perfect-scrollbar-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/styles/perfect-scrollbar.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='kyoto-wp-style-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto-child/style.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='kyoto-fonts-css'  href='//fonts.googleapis.com/css?family=Lato%3A300%2C400%2C700%2C900%7CRoboto+Slab%3A300%2C400&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='parent-style-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto/style.css?ver=5.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css'  href='http://pavlyukpetr.com/wp-content/themes/kyoto-child/style.css?ver=5.4.2' type='text/css' media='all' />
<script type='text/javascript' src='http://pavlyukpetr.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/revslider/public/assets/js/revolution.tools.min.js?ver=6.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.1.0'></script>
<link rel='https://api.w.org/' href='https://pavlyukpetr.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://pavlyukpetr.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://pavlyukpetr.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.4.2" />
<meta name="generator" content="WooCommerce 4.3.0" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by Slider Revolution 6.1.0 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(a){try{var b,c=document.getElementById(a.c).parentNode.offsetWidth;if(c=0===c||isNaN(c)?window.innerWidth:c,a.tabw=void 0===a.tabw?0:parseInt(a.tabw),a.thumbw=void 0===a.thumbw?0:parseInt(a.thumbw),a.tabh=void 0===a.tabh?0:parseInt(a.tabh),a.thumbh=void 0===a.thumbh?0:parseInt(a.thumbh),a.tabhide=void 0===a.tabhide?0:parseInt(a.tabhide),a.thumbhide=void 0===a.thumbhide?0:parseInt(a.thumbhide),a.mh=void 0===a.mh||""==a.mh?0:a.mh,"fullscreen"===a.layout||"fullscreen"===a.l)b=Math.max(a.mh,window.innerHeight);else{for(var d in a.gw=Array.isArray(a.gw)?a.gw:[a.gw],a.rl)(void 0===a.gw[d]||0===a.gw[d])&&(a.gw[d]=a.gw[d-1]);for(var d in a.gh=void 0===a.el||""===a.el||Array.isArray(a.el)&&0==a.el.length?a.gh:a.el,a.gh=Array.isArray(a.gh)?a.gh:[a.gh],a.rl)(void 0===a.gh[d]||0===a.gh[d])&&(a.gh[d]=a.gh[d-1]);var e,f=Array(a.rl.length),g=0;for(var d in a.tabw=a.tabhide>=c?0:a.tabw,a.thumbw=a.thumbhide>=c?0:a.thumbw,a.tabh=a.tabhide>=c?0:a.tabh,a.thumbh=a.thumbhide>=c?0:a.thumbh,a.rl)f[d]=a.rl[d]<window.innerWidth?0:a.rl[d];for(var d in e=f[0],f)e>f[d]&&0<f[d]&&(e=f[d],g=d);var h=c>a.gw[g]+a.tabw+a.thumbw?1:(c-(a.tabw+a.thumbw))/a.gw[g];b=a.gh[g]*h+(a.tabh+a.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(a.c).height=b,window.rs_init_css.innerHTML+="#"+a.c+"_wrapper { height: "+b+"px }"}catch(a){console.log("Failure at Presize of Slider:"+a)}};</script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-42405462-7"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-42405462-7');
        </script>
        <!-- Yandex.Metrika counter -->
        <script type="text/javascript" >
        (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
        m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
        (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

        ym(26760153, "init", {
                clickmap:true,
                trackLinks:true,
                accurateTrackBounce:true,
                webvisor:true
        });
        </script>
        <noscript><div><img src="https://mc.yandex.ru/watch/26760153" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
        <!-- /Yandex.Metrika counter -->
    </head>
    <body class="error404 theme-kyoto woocommerce-no-js elementor-default">
        <div class="l-theme-wrapper">
                        <div class="l-primary-header--responsive-wrapper l-primary-header--absolute">
                <header class="l-primary-header l-primary-header--responsive l-primary-header--wide-container">
                     <div class="container">
    <div class="d-flex align-items-center">
        <div class="a-logo a-logo--text">
    <a href="https://pavlyukpetr.com/" style="">
        Fairytheme    </a>
</div>        <div class="ml-auto d-flex align-items-center">
            <div class="l-primary-header__icons d-flex align-items-center">
                <a class="a-site-search-icon d-none d-lg-flex" href="#">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
</a>                <div class="l-primary-header__bag d-none d-lg-flex">
    <a class="l-primary-header__bag__icon" href="https://pavlyukpetr.com">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
        <span class="number">0</span>
    </a>
    <div class="o-mini-cart">
        <div class="o-mini-cart__holder widget_shopping_cart_content"></div>
    </div>
</div>

            </div>
            <a href="#" class="m-nav-menu--mobile-icon d-inline-flex" id="m-nav-menu--mobile-icon">
                <svg style="enable-background:new 0 0 139 139;" width="42px" height="42px" version="1.1" viewBox="0 0 139 139" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><line class="st0" x1="26.5" x2="112.5" y1="46.3" y2="46.3"/><line class="st0" id="XMLID_9_" x1="26.5" x2="112.5" y1="92.7" y2="92.7"/><line class="st0" id="XMLID_8_" x1="26.5" x2="112.5" y1="69.5" y2="69.5"/></svg>
            </a>
        </div>
    </div>
    <div class="m-nav-menu--mobile">
        <nav class="menu-simple-menu-container"><ul id="menu-simple-menu" class="menu"><li id="menu-item-20833" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home m-mega-menu--two menu-item-20833"><a href="https://pavlyukpetr.com/">Home</a></li>
<li id="menu-item-20834" class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20834"><a href="https://pavlyukpetr.com/themes/">Themes</a></li>
<li id="menu-item-20837" class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20837"><a href="https://pavlyukpetr.com/shop/shop-pages/my-account/">My Account</a></li>
</ul></nav>    </div>
</div>                </header>
            </div>

            <div class="l-primary-header--default-wrapper l-primary-header--absolute">
                <header class="l-primary-header l-primary-header--default l-primary-header--wide-container">
                    <div class="container">
    <div class="d-flex align-items-stretch l-primary-header__holder">
        <div class="a-logo a-logo--text">
    <a href="https://pavlyukpetr.com/" style="">
        Fairytheme    </a>
</div>        <div class="ml-auto d-flex align-items-stretch">
            <div class="d-flex align-items-stretch">
                <div class="l-primary-header--default__nav d-flex">
                    <nav class="m-nav-menu--horizontal d-flex align-items-stretch"><ul id="menu-simple-menu-1" class="menu d-flex"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home m-mega-menu--two menu-item-20833"><a href="https://pavlyukpetr.com/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20834"><a href="https://pavlyukpetr.com/themes/">Themes</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20837"><a href="https://pavlyukpetr.com/shop/shop-pages/my-account/">My Account</a></li>
</ul></nav>                </div>
                                    <div class="l-primary-header__icons d-flex align-items-stretch">
                        <a class="a-site-search-icon d-none d-lg-flex" href="#">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
</a>                        <div class="l-primary-header__bag d-none d-lg-flex">
    <a class="l-primary-header__bag__icon" href="https://pavlyukpetr.com">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
        <span class="number">0</span>
    </a>
    <div class="o-mini-cart">
        <div class="o-mini-cart__holder widget_shopping_cart_content"></div>
    </div>
</div>

                    </div>
                            </div>
        </div>
    </div>
</div>                </header>
            </div>

            <div class="m-site-search d-none d-lg-block">
    <div class="m-site-search__content">
        <div class="m-site-search__close-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </div>
    <div class="container">
        <div class="m-site-search__content__inner">
            <div class="m-site-search__form">
                <form action="https://pavlyukpetr.com/" method="get">
                    <input class="m-site-search__form__input" placeholder="Type your search..." type="search" name="s" id="search" />
                    <label class="m-site-search__form__icon">
                        <input type="submit" />
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        </span>
                    </label>
                </form>
            </div>
        </div>
    </div>
</div></div>            <div class="l-main-wrapper"><div class="t-404">
        <div class="o-hero d-flex">
            <div class="o-hero__header">
                <div class="o-hero__header__image" ></div>
                
            </div>
            <div class="o-hero__content align-self-center h-align-center">
                <div class="container">
                    <div class="o-hero__content__title h-fadeInNeuron wow"><h1>404</h1></div>
                    <div class="o-hero__content__subtitle h-fadeInNeuron wow"><p>The page you were looking for couldn&#039;t be found. The page could be<br />removed or you misspelled the word while searching for it.</p></div>
                    <a href="https://pavlyukpetr.com/" class="a-button a-button--small a-button--dark-color h-fadeInNeuron wow">Back to Homepage</a>
                </div>
            </div>
        </div>
    </div>                </div>
                                                                        <footer class="l-primary-footer l-primary-footer--dark-skin l-primary-footer--wide-container h-fadeInFooterNeuron">
                        <div class="l-primary-footer__widgets">
   <div class="container">
        <div class="l-primary-footer__widgets__space">
            <div class="row">
                                    <div class="col-sm-6 col-md-3">
                        <div id="text-2" class="widget widget_text">			<div class="textwidget"><h5 style="font-weight: 900;">Fairytheme</h5>
<p>Innovative WordPress<br />
Theme for Creatives.</p>
</div>
		</div>                    </div>
                                    <div class="col-sm-6 col-md-3">
                        <div id="text-3" class="widget widget_text">			<div class="textwidget"><h5>Contact</h5>
<h6 style="font-weight: 900;"><a href="mailto:pavliukpetr@gmail.com">pavliukpetr@gmail.com</a></h6>
</div>
		</div>                    </div>
                                    <div class="col-sm-6 col-md-3">
                        <div id="nav_menu-2" class="widget widget_nav_menu"><div class="widgettitle-wrapper"><h5 class="widgettitle">Menu</h5></div><div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-20888" class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20888"><a href="https://pavlyukpetr.com/faq/">FAQ</a></li>
<li id="menu-item-20889" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy m-mega-menu--two menu-item-20889"><a href="https://pavlyukpetr.com/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-20890" class="menu-item menu-item-type-post_type menu-item-object-page m-mega-menu--two menu-item-20890"><a href="https://pavlyukpetr.com/shop/shop-pages/my-account/">My Account</a></li>
</ul></div></div>                    </div>
                                    <div class="col-sm-6 col-md-3">
                        <div id="text-5" class="widget widget_text">			<div class="textwidget"><h6 style="font-weight: 900">Social Media</h6>
		<div data-elementor-type="section" data-elementor-id="18893" class="elementor elementor-18893" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="elementor-element elementor-element-84d13fc elementor-section-full_width elementor-section-height-default elementor-section-height-default neuron-fixed-no elementor-section elementor-top-section" data-id="84d13fc" data-element_type="section">
						<div class="elementor-container elementor-column-gap-no">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-548ec4a elementor-column elementor-col-100 elementor-top-column" data-id="548ec4a" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-7403f94 elementor-shape-square elementor-widget elementor-widget-social-icons" data-id="7403f94" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper">
							<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-57b7891" href="https://www.instagram.com/fairyweddingtheme/" target="_blank" rel="noopener noreferrer">
					<span class="elementor-screen-only">Instagram</span>
					<i class="fab fa-instagram"></i>				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-dribbble elementor-repeater-item-6a672a2" href="https://dribbble.com/Whitebody" target="_blank" rel="noopener noreferrer">
					<span class="elementor-screen-only">Dribbble</span>
					<i class="fab fa-dribbble"></i>				</a>
							<a class="elementor-icon elementor-social-icon elementor-social-icon-behance elementor-repeater-item-cc2cc0f" href="https://www.behance.net/TetianaBilotil" target="_blank" rel="noopener noreferrer">
					<span class="elementor-screen-only">Behance</span>
					<i class="fab fa-behance"></i>				</a>
					</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-55cb0ab elementor-widget elementor-widget-image" data-id="55cb0ab" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="339" height="34" src="https://pavlyukpetr.com/wp-content/uploads/2019/02/payment-img.png" class="attachment-large size-large" alt="" srcset="https://pavlyukpetr.com/wp-content/uploads/2019/02/payment-img.png 339w, https://pavlyukpetr.com/wp-content/uploads/2019/02/payment-img-300x30.png 300w" sizes="(max-width: 339px) 100vw, 339px" />											</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		
</div>
		</div>                    </div>
                            </div>
        </div>
   </div>
</div>
                        <div class="l-primary-footer__copyright">
    <div class="container">
        <div class="l-primary-footer__copyright__space">
            <div class="row d-flex align-items-center">
                <div class="col-sm-6">
                    <div class="l-primary-footer__copyright__text">
                        <p>© 2020 Fairytheme. All rights reserved.</p>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="m-social-media l-primary-footer__copyright__social-media h-align-right">
                        <ul></ul>                    </div>
                </div>
            </div>
        </div>
    </div>
</div>                    </footer>
                
                    </div>
        	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<link rel='stylesheet' id='elementor-frontend-css'  href='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=2.9.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-18893-css'  href='http://pavlyukpetr.com/wp-content/uploads/elementor/css/post-18893.css?ver=1594563610' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=2.9.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='http://pavlyukpetr.com/wp-content/uploads/elementor/css/global.css?ver=1594562961' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.12.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css'  href='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.12.0' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/pavlyukpetr.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/pavlyukpetr.com","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.3.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.3.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_3b9f63ad8e95c1595a5e9752214322a2","fragment_name":"wc_fragments_3b9f63ad8e95c1595a5e9752214322a2","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.3.0'></script>
<script type='text/javascript'>
		jQuery( 'body' ).bind( 'wc_fragments_refreshed', function() {
			var jetpackLazyImagesLoadEvent;
			try {
				jetpackLazyImagesLoadEvent = new Event( 'jetpack-lazy-images-load', {
					bubbles: true,
					cancelable: true
				} );
			} catch ( e ) {
				jetpackLazyImagesLoadEvent = document.createEvent( 'Event' )
				jetpackLazyImagesLoadEvent.initEvent( 'jetpack-lazy-images-load', true, true );
			}
			jQuery( 'body' ).get( 0 ).dispatchEvent( jetpackLazyImagesLoadEvent );
		} );
	
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/neuron-core-kyoto//assets/scripts/jquery.countdown.min.js?ver=1.0.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"http:\/\/pavlyukpetr.com","ajax_url":"https:\/\/pavlyukpetr.com\/wp-admin\/admin-ajax.php","language":"en"};
/* ]]> */
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.4.1'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/isotope.pkgd.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/packery-mode.pkgd.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/jquery.magnific-popup.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/owl.carousel.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/typed.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/wow.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/theia-sticky-sidebar.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/headroom.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/jQuery.headroom.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/perfect-scrollbar.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto/assets/scripts/kyoto.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/themes/kyoto-child/assets/scripts/custom.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-includes/js/wp-embed.min.js?ver=5.4.2'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/neuron-core-kyoto/includes/../assets/scripts/elementor.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=2.9.13'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.7.6'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6'></script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=2.9.13'></script>
<script type='text/javascript'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","downloadImage":"Download image"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"2.9.13","urls":{"assets":"http:\/\/pavlyukpetr.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"general":{"elementor_global_image_lightbox":"yes","elementor_lightbox_enable_counter":"yes","elementor_lightbox_enable_fullscreen":"yes","elementor_lightbox_enable_zoom":"yes","elementor_lightbox_enable_share":"yes","elementor_lightbox_title_src":"title","elementor_lightbox_description_src":"description"},"editorPreferences":[]},"post":{"id":0,"title":"Page not found &#8211; Fairytheme","excerpt":""}};
</script>
<script type='text/javascript' src='http://pavlyukpetr.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=2.9.13'></script>
    </body>
</html>